"use client";

import { useMemo, useState } from "react";
import type { NextPage } from "next";
import { useAccount } from "wagmi";
import { RainbowKitCustomConnectButton, EtherInput } from "~~/components/scaffold-eth";
import { SkillFileUpload } from "~~/components/SkillFileUpload";
import { SkillPreview } from "~~/components/SkillPreview";
import { useScaffoldWriteContract } from "~~/hooks/scaffold-eth";
import { notification } from "~~/utils/scaffold-eth";
import { type ValidationResult } from "~~/utils/skillValidation";

const pinataJwt = process.env.NEXT_PUBLIC_PINATA_JWT;

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, Array.from(chunk) as any);
  }
  return typeof btoa !== "undefined" ? btoa(binary) : Buffer.from(binary, "binary").toString("base64");
}

async function uploadJsonToIPFS(payload: any): Promise<string> {
  if (!pinataJwt) {
    const data = `data:application/json;utf8,${encodeURIComponent(JSON.stringify(payload))}`;
    return data;
  }
  const res = await fetch("https://api.pinata.cloud/pinning/pinJSONToIPFS", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${pinataJwt}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Pinata error: ${res.status}`);
  const json = await res.json();
  return `ipfs://${json.IpfsHash}`;
}

const CreateSkillPage: NextPage = () => {
  const { address } = useAccount();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [license, setLicense] = useState("CC-BY-4.0");
  const [category, setCategory] = useState("tools");
  const [tagsInput, setTagsInput] = useState("AI, Skill");
  const [keywordsInput, setKeywordsInput] = useState("");
  const [priceEth, setPriceEth] = useState("0");
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const [rawFileContent, setRawFileContent] = useState<string>("");

  const categories = useMemo(
    () => [
      { value: "tools", label: "工具" },
      { value: "creative", label: "创意" },
      { value: "analytics", label: "数据分析" },
      { value: "assistant", label: "智能助理" },
      { value: "education", label: "教育" },
      { value: "entertainment", label: "娱乐" },
      { value: "others", label: "其他" },
    ],
    [],
  );

  const priceWei = useMemo(() => {
    try {
      const [whole, frac = ""] = priceEth.split(".");
      const fracPadded = (frac + "000000000000000000").slice(0, 18);
      const wei = BigInt(whole || "0") * 10n ** 18n + BigInt(fracPadded || "0");
      return wei.toString();
    } catch {
      return "0";
    }
  }, [priceEth]);

  const { writeContractAsync, isPending } = useScaffoldWriteContract("SkillNFT");

  // 处理文件选择和验证结果
  const handleFileSelect = async (selectedFile: File | null) => {
    setFile(selectedFile);
    if (selectedFile) {
      try {
        const content = await selectedFile.text();
        setRawFileContent(content);
      } catch (error) {
        console.error('Error reading file content:', error);
        setRawFileContent("");
      }
    } else {
      setRawFileContent("");
    }
  };

  const handleValidationResult = (result: ValidationResult | null) => {
    setValidationResult(result);
    
    // 如果验证通过且有元数据，自动填充表单字段
    if (result?.isValid && result.metadata) {
      if (result.metadata.name && !name.trim()) {
        setName(result.metadata.name);
      }
      if (result.metadata.description && !description.trim()) {
        setDescription(result.metadata.description);
      }
      if (result.metadata.license && license === "CC-BY-4.0") {
        setLicense(result.metadata.license);
      }
    }
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!address) {
      notification.error("Please connect wallet");
      return;
    }
    if (!name.trim()) {
      notification.error("Please enter skill name");
      return;
    }
    
    // 如果有文件但验证失败，阻止提交
    if (file && validationResult && !validationResult.isValid) {
      notification.error("Please fix file validation errors before submitting");
      return;
    }
    
    try {
      setUploading(true);
      let fileObj: any = undefined;
      if (file) {
        const content = await file.arrayBuffer();
        const b64 = arrayBufferToBase64(content);
        fileObj = { 
          name: file.name, 
          type: file.type, 
          size: file.size, 
          base64: b64,
          // 如果有验证结果，包含元数据
          ...(validationResult?.isValid && validationResult.metadata ? {
            metadata: validationResult.metadata
          } : {})
        };
      }
      const parseCommaList = (value: string) =>
        value
          .split(/[，,]/)
          .map(item => item.trim())
          .filter(Boolean);

      const metadata = {
        name,
        description,
        license,
        category,
        tags: parseCommaList(tagsInput),
        keywords: parseCommaList(keywordsInput || tagsInput),
        createdAt: new Date().toISOString(),
        skill: fileObj,
        // 如果有验证通过的技能元数据，也包含在顶层
        ...(validationResult?.isValid && validationResult.metadata ? {
          skillMetadata: validationResult.metadata
        } : {})
      };
      const tokenURI = await uploadJsonToIPFS(metadata);
      const tx = await writeContractAsync({ functionName: "mintSkill", args: [address, tokenURI, BigInt(priceWei)] });
      notification.success(`Skill created successfully! Transaction: ${tx}`);
      
      // 重置表单
      setName("");
      setDescription("");
      setLicense("CC-BY-4.0");
      setCategory("tools");
      setTagsInput("AI, Skill");
      setKeywordsInput("");
      setPriceEth("0");
      setFile(null);
      setValidationResult(null);
      setRawFileContent("");
    } catch (err: any) {
      console.error(err);
      notification.error(err?.message || "Create failed");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <div className="flex items-start justify-between mb-8">
        <div>
          <div className="flex items-center gap-4 mb-6">
          <img src="/logo.svg" alt="MetaSkill" className="h-30 w-auto" />
          <span className="text-3xl font-bold">创建技能包</span>
        </div>
          <p className="text-sm opacity-70 mt-1">上传技能说明与资源，设置价格，铸造为链上 NFT。</p>
        </div>
        <RainbowKitCustomConnectButton />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* 左侧：表单卡片 */}
        <section className="card bg-base-100 shadow p-6 space-y-4">
          <form className="space-y-4" onSubmit={onSubmit}>
            <div className="form-control">
              <label className="label">
                <span className="label-text">技能名称 *</span>
              </label>
              <input 
                className="input input-bordered w-full" 
                value={name} 
                onChange={e => setName(e.target.value)} 
                placeholder="例如：图像描述生成" 
                required
              />
            </div>
            
            <div className="form-control">
              <label className="label">
                <span className="label-text">技能描述</span>
              </label>
              <textarea 
                className="textarea textarea-bordered w-full" 
                rows={4} 
                value={description} 
                onChange={e => setDescription(e.target.value)} 
                placeholder="简要描述这个技能的功能和用途" 
              />
            </div>
            
            <div className="form-control">
              <label className="label">
                <span className="label-text">许可证</span>
              </label>
              <input 
                className="input input-bordered w-full" 
                value={license} 
                onChange={e => setLicense(e.target.value)} 
                placeholder="例如：CC-BY-4.0" 
              />
            </div>
            
            <div className="form-control">
              <label className="label">
                <span className="label-text">价格 (ETH)</span>
              </label>
              <div className="w-full">
                <EtherInput 
                  name="price" 
                  value={priceEth} 
                  onChange={setPriceEth} 
                  placeholder="0.00" 
                />
              </div>
            </div>
            
            <button 
              className="btn btn-primary btn-lg w-full" 
              type="submit" 
              disabled={isPending || uploading || (file && validationResult && !validationResult.isValid)}
            >
              {isPending || uploading ? (
                <>
                  <span className="loading loading-spinner loading-sm"></span>
                  处理中...
                </>
              ) : (
                "立即创建"
              )}
            </button>
          </form>
          
          <div className="alert alert-info">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="stroke-current shrink-0 w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span className="text-sm">未配置 IPFS 时，元数据将以 data URI 形式保存，仅用于本地演示。</span>
          </div>
        </section>

        {/* 右侧：上传与预览卡片（置顶保持可见） */}
        <div className="space-y-6 lg:sticky lg:top-24">
          <section className="card bg-base-100 shadow p-6">
            <h2 className="text-xl font-semibold mb-4">技能文件上传</h2>
            <SkillFileUpload
              onFileSelect={handleFileSelect}
              onValidationResult={handleValidationResult}
              disabled={uploading || isPending}
            />
          </section>
          
          {validationResult?.isValid && validationResult.metadata && (
            <section className="card bg-base-100 shadow p-6">
              <h2 className="text-xl font-semibold mb-4">技能预览</h2>
              <SkillPreview
                metadata={validationResult.metadata}
                rawContent={rawFileContent}
              />
            </section>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreateSkillPage;
