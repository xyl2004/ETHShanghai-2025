export default function Home() {
    return (
        <div className="flex font-bold flex-col gap-6 items-center justify-center h-screen w-[100vw]">
            <h1 className="text-green-500 text-3xl">Hello, Vibe3</h1>
            <div className="card">
                Start using [vibe3] by sending a prompt
            </div>
        </div>
    )
}