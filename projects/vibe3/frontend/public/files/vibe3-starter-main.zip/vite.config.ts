import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
import VitePluginVibe3Inspector from "vite-plugin-vibe3-inspector";

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const envs = loadEnv(mode, process.cwd());
  return {
    plugins: [
      react(),
      tailwindcss(),
      envs.VITE_INSPECTOR_MODE === "true" && VitePluginVibe3Inspector({debug: false}),
    ].filter(Boolean),
    resolve: {
      alias: {
        "@": path.resolve(__dirname, "./src"),
      },
    },
  };
});
